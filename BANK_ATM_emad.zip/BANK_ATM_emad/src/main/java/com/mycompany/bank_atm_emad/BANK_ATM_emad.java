package com.mycompany.bank_atm_emad;

public class BANK_ATM_emad {

    public static void main(String[] args) {
        LOGIN loginFrame = new LOGIN();
        loginFrame.pack();
        loginFrame.setVisible(true);
    }
}
